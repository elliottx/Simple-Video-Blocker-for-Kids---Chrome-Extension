let currentRules = new Map();

// Badge management functions
function updateBadge() {
  try {
    chrome.storage.sync.get(['allowYouTube', 'allowTikTok', 'allowNetflix', 'allowHulu'], (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error reading storage for badge update:', chrome.runtime.lastError.message);
        return;
      }
      
      const platforms = ['allowYouTube', 'allowTikTok', 'allowNetflix', 'allowHulu'];
      const blockedCount = platforms.filter(platform => !result[platform]).length;
      const totalCount = platforms.length;
      
      // Set badge text to show blocked/total ratio
      const badgeText = blockedCount > 0 ? `${blockedCount}/${totalCount}` : '';
      
      chrome.action.setBadgeText({ text: badgeText }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error setting badge text:', chrome.runtime.lastError.message);
        }
      });
      
      // Set badge color based on blocking status
      let badgeColor = '#4CAF50'; // Green for all allowed
      if (blockedCount === totalCount) {
        badgeColor = '#f44336'; // Red for all blocked
      } else if (blockedCount > 0) {
        badgeColor = '#FF9800'; // Orange for partial blocking
      }
      
      chrome.action.setBadgeBackgroundColor({ color: badgeColor }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error setting badge color:', chrome.runtime.lastError.message);
        }
      });
      
      // Update title with current status
      const allowedPlatforms = platforms.filter(p => result[p]).map(p => p.replace('allow', '')).join(', ');
      const blockedPlatforms = platforms.filter(p => !result[p]).map(p => p.replace('allow', '')).join(', ');
      
      let title = 'Simple Video Blocker for Kids\n';
      if (blockedCount === 0) {
        title += 'All platforms allowed';
      } else if (blockedCount === totalCount) {
        title += 'All platforms blocked';
      } else {
        title += `Blocked: ${blockedPlatforms}\nAllowed: ${allowedPlatforms}`;
      }
      
      chrome.action.setTitle({ title: title }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error setting action title:', chrome.runtime.lastError.message);
        }
      });
    });
  } catch (error) {
    console.error('Exception in updateBadge:', error);
  }
}

function generateUniqueId() {
  return Math.floor(Math.random() * 1000000000) + 1;
}

function createRule(urlFilter, resourceTypes) {
  let id;
  do {
    id = generateUniqueId();
  } while (currentRules.has(id));

  const rule = {
    id: id,
    priority: 1,
    action: { type: 'block' },
    condition: { urlFilter, resourceTypes }
  };
  currentRules.set(id, rule);
  return rule;
}

function updateRules() {
  try {
    chrome.storage.sync.get(['allowYouTube', 'allowTikTok', 'allowNetflix', 'allowHulu'], (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error reading storage for updateRules:', chrome.runtime.lastError.message);
        return;
      }
      
      const newRules = [];
      const rulesToRemove = Array.from(currentRules.keys());

      currentRules.clear();

    if (!result.allowYouTube) {
      newRules.push(
        createRule('*youtube.com/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other']),
        createRule('*youtu.be/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other']),
        createRule('*youtube-nocookie.com/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other']),
        createRule('*.googlevideo.com/*', ['media', 'xmlhttprequest', 'other'])
      );
    }
    if (!result.allowTikTok) {
      newRules.push(
        createRule('*tiktok.com/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other']),
        createRule('*vm.tiktok.com/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other']),
        createRule('*vt.tiktok.com/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other']),
        createRule('*tiktokv.com/*', ['media', 'xmlhttprequest', 'other']),
        createRule('*tiktokcdn.com/*', ['media', 'xmlhttprequest', 'other']),
        createRule('*musical.ly/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other'])
      );
    }
    if (!result.allowNetflix) {
      newRules.push(
        createRule('*netflix.com/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other']),
        createRule('*.nflxvideo.net/*', ['media', 'xmlhttprequest', 'other']),
        createRule('*.nflxso.net/*', ['media', 'xmlhttprequest', 'other'])
      );
    }
    if (!result.allowHulu) {
      newRules.push(
        createRule('*hulu.com/*', ['sub_frame', 'media', 'xmlhttprequest', 'object', 'other']),
        createRule('*.hulustream.com/*', ['media', 'xmlhttprequest', 'other'])
      );
    }
    
    console.log('Updating rules:', { removeRuleIds: rulesToRemove, addRules: newRules });

    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: rulesToRemove,
      addRules: newRules
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error updating rules:', JSON.stringify(chrome.runtime.lastError));
        console.error('Error details:', chrome.runtime.lastError.message);
        // Fallback: try again with fewer rules if we hit limits
        if (chrome.runtime.lastError.message.includes('quota')) {
          console.log('Attempting fallback with essential rules only');
          const essentialRules = newRules.slice(0, 10); // Limit to first 10 rules
          chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: rulesToRemove,
            addRules: essentialRules
          });
        }
      } else {
        console.log('Rules updated successfully');
        updateBadge(); // Update badge when rules change
      }
    });
    });
  } catch (error) {
    console.error('Exception in updateRules:', error);
  }
}

function removeAllRules() {
  try {
    chrome.declarativeNetRequest.getDynamicRules((rules) => {
      if (chrome.runtime.lastError) {
        console.error('Error getting dynamic rules:', chrome.runtime.lastError.message);
        return;
      }
      
      const ruleIds = rules.map(rule => rule.id);
      chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: ruleIds
      }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error removing all rules:', JSON.stringify(chrome.runtime.lastError));
        } else {
          console.log('All rules removed successfully');
          currentRules.clear();
          updateRules();
        }
      });
    });
  } catch (error) {
    console.error('Exception in removeAllRules:', error);
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  console.log('Extension installed. Removing all rules and initializing...');
  
  try {
    // Force set all platforms to blocked on fresh install or update
    if (details.reason === 'install' || details.reason === 'update') {
      // Clear any existing values and force defaults
      chrome.storage.sync.clear(() => {
        chrome.storage.sync.set({
          allowYouTube: false,
          allowTikTok: false,
          allowNetflix: true,
          allowHulu: true
        }, () => {
          if (chrome.runtime.lastError) {
            console.error('Error setting default storage:', chrome.runtime.lastError.message);
          } else {
            console.log('Default settings initialized: YouTube/TikTok blocked, Netflix/Hulu allowed');
            removeAllRules();
            updateBadge(); // Update badge after setting defaults
          }
        });
      });
    } else {
      removeAllRules();
    }
  } catch (error) {
    console.error('Exception in onInstalled:', error);
  }
});

// Also initialize rules when extension starts (browser restart, etc.)
chrome.runtime.onStartup.addListener(() => {
  console.log('Extension starting up. Initializing rules...');
  updateRules();
  updateBadge(); // Update badge on startup
});

// Handle action click to open options page
chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage((error) => {
    if (chrome.runtime.lastError) {
      console.error('Error opening options page:', chrome.runtime.lastError.message);
    }
  });
});

chrome.storage.onChanged.addListener((changes) => {
  try {
    if (changes.allowYouTube || changes.allowTikTok || changes.allowNetflix || changes.allowHulu) {
      console.log('Settings changed. Updating rules...');
      updateRules();
      updateBadge(); // Update badge when settings change
      
      // Reload affected tabs when settings change
      chrome.tabs.query({}, (tabs) => {
        if (chrome.runtime.lastError) {
          console.error('Error querying tabs:', chrome.runtime.lastError.message);
          return;
        }
        
        tabs.forEach(tab => {
          if (tab.url) {
            const isYouTube = tab.url.includes('youtube.com') || tab.url.includes('youtu.be');
            const isTikTok = tab.url.includes('tiktok.com');
            const isNetflix = tab.url.includes('netflix.com');
            const isHulu = tab.url.includes('hulu.com');
            
            if ((changes.allowYouTube && isYouTube) || 
                (changes.allowTikTok && isTikTok) ||
                (changes.allowNetflix && isNetflix) ||
                (changes.allowHulu && isHulu)) {
              console.log('Reloading affected tab:', tab.url);
              chrome.tabs.reload(tab.id, (error) => {
                if (chrome.runtime.lastError) {
                  console.error('Error reloading tab:', chrome.runtime.lastError.message);
                }
              });
            }
          }
        });
      });
    }
  } catch (error) {
    console.error('Exception in storage change listener:', error);
  }
});