let settings = {
  allowHulu: false,
  allowNetflix: false,
  allowYouTube: false,
  allowTikTok: false
};

function loadSettings() {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.sync.get(['allowHulu', 'allowNetflix', 'allowYouTube', 'allowTikTok'], (result) => {
        if (chrome.runtime.lastError) {
          console.error('Error loading settings in content script:', chrome.runtime.lastError.message);
          reject(chrome.runtime.lastError);
          return;
        }
        settings = { ...settings, ...result };
        console.log('Content script settings loaded:', settings);
        resolve();
      });
    } catch (error) {
      console.error('Exception in loadSettings:', error);
      reject(error);
    }
  });
}

function isBlockedDomain(domain) {
  // Check if current domain is one we should potentially block
  return (
    (domain.includes('hulu.com') && !settings.allowHulu) ||
    (domain.includes('netflix.com') && !settings.allowNetflix) ||
    ((domain.includes('youtube.com') || domain.includes('youtu.be')) && !settings.allowYouTube) ||
    ((domain.includes('tiktok.com') || domain.includes('musical.ly')) && !settings.allowTikTok)
  );
}

function muteAndPauseMedia() {
  const currentDomain = window.location.hostname;
  if (!isBlockedDomain(currentDomain)) return;

  const mediaElements = document.querySelectorAll('video, audio');
  mediaElements.forEach(element => {
    element.muted = true;
    element.pause();
  });
}

function removeVideos() {
  const currentDomain = window.location.hostname;
  
  // Only remove embedded YouTube/TikTok iframes from any domain
  const iframes = document.getElementsByTagName('iframe');
  for (let i = iframes.length - 1; i >= 0; i--) {
    const src = iframes[i].src.toLowerCase();
    if (
      (src.includes('youtube.com/embed') && !settings.allowYouTube) ||
      (src.includes('youtu.be') && !settings.allowYouTube) ||
      (src.includes('youtube-nocookie.com') && !settings.allowYouTube) ||
      ((src.includes('tiktok.com') || src.includes('musical.ly')) && !settings.allowTikTok)
    ) {
      iframes[i].remove();
    }
  }

  // Only remove videos if we're actually on a blocked domain
  if (isBlockedDomain(currentDomain)) {
    // Mute and remove video elements
    const videos = document.getElementsByTagName('video');
    for (let i = videos.length - 1; i >= 0; i--) {
      videos[i].muted = true;
      videos[i].pause();
      videos[i].remove();
    }

    // Mute audio elements
    const audios = document.getElementsByTagName('audio');
    for (let i = audios.length - 1; i >= 0; i--) {
      audios[i].muted = true;
      audios[i].pause();
    }
  }

  // Remove YouTube custom embed elements from any domain
  if (!settings.allowYouTube) {
    const ytElements = document.getElementsByTagName('yt-embed');
    for (let i = ytElements.length - 1; i >= 0; i--) {
      ytElements[i].remove();
    }
  }
}

function removeYouTubeNoCookieVideos() {
  if (settings.allowYouTube) return;

  const videos = document.querySelectorAll('video[src^="blob:https://www.youtube-nocookie.com/"]');
  videos.forEach(video => {
    video.pause();
    video.remove();
  });
}

// Listen for storage changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'sync') {
    try {
      // Update settings when they change
      chrome.storage.sync.get(['allowHulu', 'allowNetflix', 'allowYouTube', 'allowTikTok'], (result) => {
        if (chrome.runtime.lastError) {
          console.error('Error updating settings in content script:', chrome.runtime.lastError.message);
          return;
        }
        
        settings = { ...settings, ...result };
        console.log('Settings updated:', settings);
        
        // Reapply blocking based on new settings
        const currentDomain = window.location.hostname;
        if (!isBlockedDomain(currentDomain)) {
          // If now allowed, we might need to reload the page to restore functionality
          console.log('Platform now allowed, you may need to refresh the page');
        } else {
          // If now blocked, immediately block content
          try {
            removeVideos();
            muteAndPauseMedia();
          } catch (error) {
            console.error('Error applying blocks after settings change:', error);
          }
        }
      });
    } catch (error) {
      console.error('Exception in storage change listener:', error);
    }
  }
});

loadSettings().then(() => {
  console.log('Initial settings loaded:', settings);
  
  try {
    // Run on page load
    removeVideos();
    muteAndPauseMedia();

    // Set up a MutationObserver to handle dynamically loaded content
    const observer = new MutationObserver(() => {
      try {
        removeVideos();
        muteAndPauseMedia();
      } catch (error) {
        console.error('Error in MutationObserver callback:', error);
      }
    });
    
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    } else {
      // Wait for body to be available
      const bodyObserver = new MutationObserver(() => {
        if (document.body) {
          bodyObserver.disconnect();
          observer.observe(document.body, { childList: true, subtree: true });
        }
      });
      bodyObserver.observe(document.documentElement, { childList: true });
    }
  } catch (error) {
    console.error('Error during content script initialization:', error);
  }

  // Block audio context only for blocked domains
  const originalAudioContext = window.AudioContext || window.webkitAudioContext;
  window.AudioContext = window.webkitAudioContext = function() {
    const currentDomain = window.location.hostname;
    if (!isBlockedDomain(currentDomain)) {
      return new originalAudioContext();
    }
    return {
      createMediaElementSource: function() {
        return { connect: function() {} };
      },
      createGain: function() {
        return { connect: function() {} };
      },
      // Add other methods as needed, returning dummy objects
    };
  };

  // Intercept play attempts only on blocked domains
  const originalPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function() {
    const currentDomain = window.location.hostname;
    if (!isBlockedDomain(currentDomain)) {
      return originalPlay.apply(this);
    }
    this.pause();
    this.muted = true;
    return Promise.reject(new DOMException('Play prevented by extension', 'NotAllowedError'));
  };
}).catch((error) => {
  console.error('Error loading initial settings:', error);
  // Continue with default settings (all blocked) if storage fails
  console.log('Continuing with default blocked settings due to storage error');
  try {
    removeVideos();
    muteAndPauseMedia();
  } catch (blockingError) {
    console.error('Error applying default blocking:', blockingError);
  }
});
