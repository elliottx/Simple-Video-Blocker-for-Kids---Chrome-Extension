document.addEventListener('DOMContentLoaded', () => {
    const platforms = ['YouTube', 'TikTok', 'Netflix', 'Hulu'];
    const saveStatus = document.getElementById('saveStatus');
    let saveTimeout;

    function showSaveStatus(message, isSuccess = true) {
        saveStatus.textContent = message;
        saveStatus.style.background = isSuccess ? '#4CAF50' : '#f44336';
        saveStatus.classList.add('show');
        
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
            saveStatus.classList.remove('show');
        }, 2000);
    }

    function loadSettings() {
        const storageKeys = platforms.map(p => `allow${p}`);
        
        try {
            chrome.storage.sync.get(storageKeys, (result) => {
                if (chrome.runtime.lastError) {
                    console.error('Error loading settings:', chrome.runtime.lastError.message);
                    showSaveStatus('Error loading settings', false);
                    return;
                }
                
                platforms.forEach(platform => {
                    const blockCheckbox = document.getElementById(`block${platform}`);
                    const allowKey = `allow${platform}`;
                    
                    if (blockCheckbox) {
                        // If allowPlatform is undefined (first install), default to false (blocked)
                        const isAllowed = result[allowKey] !== undefined ? result[allowKey] : false;
                        // Checkbox is checked when platform is blocked (inverted)
                        blockCheckbox.checked = !isAllowed;
                        updateToggleState(blockCheckbox);
                    }
                });
            });
        } catch (error) {
            console.error('Exception in loadSettings:', error);
            showSaveStatus('Error loading settings', false);
        }
    }

    function updateToggleState(checkbox) {
        const settingItem = checkbox.closest('.setting-item');
        if (settingItem) {
            if (checkbox.checked) {
                // Checked = Blocked (red tint)
                settingItem.style.background = '#ffebee';
            } else {
                // Unchecked = Allowed (green tint)
                settingItem.style.background = '#e8f5e9';
            }
        }
    }

    function saveSettings(platform) {
        try {
            const blockCheckbox = document.getElementById(`block${platform}`);
            if (!blockCheckbox) {
                console.error(`Checkbox not found for platform: ${platform}`);
                showSaveStatus('Error: Invalid platform', false);
                return;
            }
            
            const isBlocked = blockCheckbox.checked;
            const allowKey = `allow${platform}`;
            
            // Validate platform name
            if (!platforms.includes(platform)) {
                console.error(`Invalid platform: ${platform}`);
                showSaveStatus('Error: Invalid platform', false);
                return;
            }
            
            // Store as allow value (inverted from UI)
            const settings = {
                [allowKey]: !isBlocked
            };
            
            chrome.storage.sync.set(settings, () => {
                if (chrome.runtime.lastError) {
                    showSaveStatus('Error saving settings', false);
                    console.error('Error saving settings:', chrome.runtime.lastError);
                } else {
                    const status = isBlocked ? 'blocked' : 'allowed';
                    showSaveStatus(`${platform} ${status}`, true);
                }
            });
        } catch (error) {
            console.error('Exception in saveSettings:', error);
            showSaveStatus('Error saving settings', false);
        }
    }

    // Initialize default values on first install
    function initializeDefaults() {
        const storageKeys = platforms.map(p => `allow${p}`);
        
        try {
            chrome.storage.sync.get(storageKeys, (result) => {
                if (chrome.runtime.lastError) {
                    console.error('Error reading storage for defaults:', chrome.runtime.lastError.message);
                    showSaveStatus('Error initializing settings', false);
                    return;
                }
                
                const defaults = {};
                let needsDefaults = false;
                
                platforms.forEach(platform => {
                    const allowKey = `allow${platform}`;
                    if (result[allowKey] === undefined) {
                        // Set platform-specific defaults
                        if (platform === 'Netflix' || platform === 'Hulu') {
                            defaults[allowKey] = true; // Netflix and Hulu allowed by default
                        } else {
                            defaults[allowKey] = false; // YouTube and TikTok blocked by default
                        }
                        needsDefaults = true;
                    }
                });
                
                if (needsDefaults) {
                    chrome.storage.sync.set(defaults, () => {
                        if (chrome.runtime.lastError) {
                            console.error('Error setting defaults:', chrome.runtime.lastError.message);
                            showSaveStatus('Error initializing settings', false);
                        } else {
                            console.log('Default settings initialized: YouTube/TikTok blocked, Netflix/Hulu allowed');
                            loadSettings();
                        }
                    });
                } else {
                    loadSettings();
                }
            });
        } catch (error) {
            console.error('Exception in initializeDefaults:', error);
            showSaveStatus('Error initializing settings', false);
        }
    }

    // Initialize settings
    initializeDefaults();

    // Add event listeners for each platform
    platforms.forEach(platform => {
        const checkbox = document.getElementById(`block${platform}`);
        if (checkbox) {
            checkbox.addEventListener('change', (e) => {
                updateToggleState(e.target);
                saveSettings(platform);
            });
        }
    });

    // Click anywhere on setting item to toggle
    const settingItems = document.querySelectorAll('.setting-item');
    settingItems.forEach(item => {
        item.addEventListener('click', (e) => {
            if (!e.target.closest('.toggle-switch')) {
                const toggle = item.querySelector('input[type="checkbox"]');
                if (toggle) {
                    toggle.checked = !toggle.checked;
                    toggle.dispatchEvent(new Event('change'));
                }
            }
        });
    });

    // Feedback System - Direct link to Google Form
    const feedbackBtn = document.getElementById('feedbackBtn');
    const reviewBtn = document.getElementById('reviewBtn');
    
    // Event listener - Direct link to Google Form
    feedbackBtn.addEventListener('click', () => {
        window.open('https://docs.google.com/forms/d/e/1FAIpQLSfd-ZUiDCOylX7BTwNpnS-_A2Da-UBtVFnb2idDjmNfdBcU9Q/viewform?usp=dialog', '_blank');
    });
    
    // Event listener - Direct link to Chrome Web Store reviews
    reviewBtn.addEventListener('click', () => {
        window.open('https://chromewebstore.google.com/detail/simple-video-blocker-for/gilffjhghogfgfdjinemcccoealbnoeg/reviews', '_blank');
    });
});